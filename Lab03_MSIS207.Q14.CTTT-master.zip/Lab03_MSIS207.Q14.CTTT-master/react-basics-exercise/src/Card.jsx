// src/Card.jsx

import PropTypes from 'prop-types';

/*
 * 1. Nhận props 'title' và 'children'.
 * - 'children' là một prop đặc biệt trong React.
 * - Nó chứa bất cứ thứ gì bạn đặt GIỮA thẻ mở <Card> và thẻ đóng </Card>.
 */
function Card({ title, children }) {
  const cardStyle = {
    border: '1px solid #ddd',
    borderRadius: '8px',
    padding: '16px',
    margin: '16px 0',
    boxShadow: '0 2px 4px rgba(0,0,0,0.1)',
  };

  return (
    // 2. Render cấu trúc theo yêu cầu [cite: 106, 107]
    <div className="card" style={cardStyle}>
      <h3 className="card-title">{title}</h3>
      <hr />
      <div className="card-content">
        {/* 3. 'children' được render tại đây */}
        {children}
      </div>
    </div>
  );
}

Card.propTypes = {
  title: PropTypes.string.isRequired,
  children: PropTypes.node.isRequired, // 'node' nghĩa là bất cứ thứ gì có thể render
};

export default Card;