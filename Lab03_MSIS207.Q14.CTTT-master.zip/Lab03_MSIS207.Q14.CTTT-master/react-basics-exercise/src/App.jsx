// src/App.jsx

import UserProfile from './UserProfile.jsx';
import Counter from './Counter.jsx';
import Login from './Login.jsx';
import Card from './Card.jsx';

// 1. Tạo hai đối tượng user khác nhau (theo yêu cầu Bài 4)
const user1 = {
  name: 'Bruce Wayne',
  email: 'bruce@wayne.com',
  avatarUrl: 'https://imgur.com/gallery/batman-many-different-ways-RD1Wbkf#GD7q5as', // Giữ tạm ảnh này
  imageSize: 90,
};

const user2 = {
  name: 'Clark Kent',
  email: 'clark@dailyplanet.com',
  avatarUrl: 'https://i.imgur.com/yXOvdOSs.jpg', // Giữ tạm ảnh này
  imageSize: 90,
};

function App() {
    return (  
    <div>
      <h1>My Application</h1>
      
      <Login />
      <Counter />
      
      {/*
       * 3. Sử dụng Card làm component bọc.
       * - 'title' được truyền như một prop bình thường[cite: 111].
       * - '<UserProfile ... />' giờ là 'children' của Card.
       */}
      <Card title="UserProfile 1">
        <UserProfile userData={user1} theme="dark" />
      </Card>
      
      <Card title="UserProfile 2">
        <UserProfile userData={user2} />
      </Card>
    </div>
  );
}

export default App;