// src/Counter.jsx

// 1. Import 'useState' từ React. Đây là một "Hook".
import { useState } from 'react';

function Counter() {
  /*
   * 2. Sử dụng hook 'useState'[cite: 72].
   * - Nó trả về một cặp giá trị: [giá trị state hiện tại, hàm để cập nhật nó].
   * - 'count' là biến state, được khởi tạo với giá trị 0[cite: 72].
   * - 'setCount' là hàm chúng ta sẽ gọi để thay đổi giá trị của 'count'.
   */
  const [count, setCount] = useState(0);

  // 3. Tạo một hàm xử lý (handler) để gọi khi nhấn nút
  const incrementCount = () => {
    // Chúng ta gọi 'setCount' để cập nhật state.
    // React sẽ tự động re-render (kết xuất lại) component này.
    setCount(count + 1);
  };

  return (
    <div style={{ border: '1px solid #ccc', padding: '10px', margin: '10px 0' }}>
      <h3>Exercise 5</h3>
      {/* 4. Hiển thị giá trị 'count' hiện tại [cite: 73] */}
      <p>Number of count: {count}</p>
      
      {/* 5. Gán hàm 'incrementCount' cho sự kiện 'onClick' của nút [cite: 74] */}
      <button onClick={incrementCount}>
        Click Here
      </button>
    </div>
  );
}

export default Counter;