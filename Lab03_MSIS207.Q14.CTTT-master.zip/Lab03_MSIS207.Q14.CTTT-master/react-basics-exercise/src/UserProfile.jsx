// src/UserProfile.jsx

// 1. Import PropTypes sau khi đã cài đặt
import PropTypes from 'prop-types';

/*
 * 2. Nhận props bằng cách dùng 'prop destructuring'.
 * - Thay vì (props), chúng ta dùng ({ userData, theme = 'light' })
 * - 'userData' là prop chúng ta đã truyền từ App.jsx.
 * - 'theme = 'light'' là cú pháp ES6 default parameter (yêu cầu Bài 4, phần 2).
 * Nếu 'App.jsx' không truyền 'theme', nó sẽ tự động là 'light'.
 */
function UserProfile({ userData, theme = 'light' }) {
  
  // 3. XÓA đối tượng 'user' được code cứng ở Bài 3.
  // Component này không còn "sở hữu" dữ liệu nữa, nó nhận dữ liệu qua props.

  /*
   * 4. Thêm className động vào thẻ bọc (wrapper).
   * Chúng ta phải đổi Fragment (<>...</>) từ Bài 3 thành <div>
   * để có thể gán className cho nó.
   */
  return (
    <div className={`profile-card theme-${theme}`}>
      <h2>User Profile</h2>
      
      {/* 5. Sử dụng dữ liệu từ 'userData' prop (thay vì 'user') */}
      <img
        className="profile-avatar"
        src={userData.avatarUrl}
        alt={userData.name}
        width={userData.imageSize}
        height={userData.imageSize}
      />
      
      <p>Name: {userData.name}</p>
      <p>Email: {userData.email}</p>
    </div>
  );
}

// 6. Thêm phần xác thực 'PropTypes' (yêu cầu Bài 4, phần 2)
UserProfile.propTypes = {
  // Yêu cầu 'userData' phải là một đối tượng (object)
  // và có 'shape' (hình dạng) cụ thể:
  userData: PropTypes.shape({
    name: PropTypes.string.isRequired, // 'name' là string và bắt buộc
    email: PropTypes.string,           // 'email' là string (không bắt buộc)
    avatarUrl: PropTypes.string,       // Thêm các trường khác cho đầy đủ
    imageSize: PropTypes.number,
  }).isRequired, // Bản thân 'userData' cũng là bắt buộc

  // Yêu cầu 'theme' phải là một string
  theme: PropTypes.string,
};

export default UserProfile;