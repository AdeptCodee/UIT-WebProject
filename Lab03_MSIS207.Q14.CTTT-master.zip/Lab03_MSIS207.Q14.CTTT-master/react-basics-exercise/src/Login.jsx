// src/Login.jsx

import { useState } from 'react';

function Login() {
  /*
   * 1. Quản lý form bằng một state object duy nhất [cite: 95]
   * (theo yêu cầu Phần 2)
   */
  const [formData, setFormData] = useState({
    username: '',
    password: '',
  });

  /*
   * 2. Tạo một hàm 'handleChange' duy nhất [cite: 97]
   * Hàm này hoạt động cho TẤT CẢ các ô input.
   */
  const handleChange = (event) => {
    // Lấy 'name' (ví dụ: "username", "password") [cite: 98]
    // và 'value' (ví dụ: "test", "123") từ ô input đã kích hoạt sự kiện.
    const { name, value } = event.target;

    // Cập nhật state
    setFormData((prevFormData) => ({
      ...prevFormData,  // 1. Sao chép tất cả các giá trị cũ
      [name]: value,      // 2. Ghi đè chỉ thuộc tính [name] đã thay đổi
    }));
  };

  /*
   * 3. Hàm xử lý 'onSubmit' cho form 
   */
  const handleSubmit = (event) => {
    // Ngăn chặn trình duyệt tải lại trang 
    event.preventDefault();
    
    // Ghi dữ liệu state 'formData' hiện tại ra console 
    console.log('Dữ liệu form:', formData);
    alert(`Xin chào, ${formData.username}!`);
  };

  return (
    <div style={{ border: '1px solid #ccc', padding: '10px', margin: '10px 0' }}>
      <h3>Login Form</h3>
      
      {/* 4. Gắn hàm handleSubmit vào sự kiện 'onSubmit' của form  */}
      <form onSubmit={handleSubmit}>
        <div>
          <label>Username: </label>
          <input
            type="text"
            name="username" // 'name' phải khớp với key trong state 'formData' [cite: 98]
            value={formData.username} // 5. 'value' được gán từ state [cite: 90]
            onChange={handleChange}      // 6. 'onChange' cập nhật state [cite: 90]
          />
        </div>
        
        {/* (Yêu cầu Phần 2: Thêm trường password) [cite: 94] */}
        <div>
          <label>Password: </label>
          <input
            type="password"
            name="password" // 'name' phải khớp với key trong state 'formData'
            value={formData.password}
            onChange={handleChange}
          />
        </div>
        
        <button type="submit">Đăng nhập</button>
      </form>

      {/* 7. Hiển thị state để xác nhận (Yêu cầu Phần 1) [cite: 92] */}
      <p>Entering a valid username: {formData.username}</p>
      <p>Entering a valid password: {formData.password}</p>
    </div>
  );
}

export default Login;